<?php
$GLOBALS['lang'] = 'cn';
$GLOBALS['auteur'] = 'admin';
$GLOBALS['email'] = 'mail@example.com';
$GLOBALS['racine'] = 'http://3lqeyh3445.qq.com/1/';
$GLOBALS['format_date'] = '0';
$GLOBALS['format_heure'] = '0';
$GLOBALS['fuseau_horaire'] = 'UTC';
?>